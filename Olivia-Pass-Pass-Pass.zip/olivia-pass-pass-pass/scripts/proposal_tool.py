#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""播音专业开题报告（设计类）：机械核查 + Word 原生批注写回。

子命令：
  check <input.docx> [-o report.json] [--base-year 2026]
        输出段落清单（带索引）、各栏字数、参考文献统计、关键词、第一人称线索。
  refs  <input.docx> [-o refs.json]
        输出参考文献的「题名 + 作者」检索串，供逐条联网核验。
  apply <input.docx> <comments.json> [-o output.docx] [--author 名称] [--initials 缩写]
        按批注清单写回 Word 原生批注，生成批注版 .docx（不改动原文件）。

依赖：python-docx >= 1.2.0（apply 需要 add_comment）；pypinyin 可选（排序检查）。
段落索引在 check / apply 之间保持一致，按同一遍历顺序生成。
"""

import argparse
import json
import os
import re
import sys

try:
    import docx
    from docx import Document
    from docx.oxml.ns import qn
    from docx.table import Table
    from docx.text.paragraph import Paragraph
except ImportError:
    sys.stderr.write("缺少 python-docx，请先执行：pip install \"python-docx>=1.2.0\"\n")
    sys.exit(1)


SECTION_MARKERS = [
    ("目的及意义", "目的及意义"),
    ("基本内容和实施方案", "基本内容和实施方案"),
    ("文献综述", "文献综述"),
    ("参考文献", "已查阅主要参考文献"),
    ("表尾", "指导教师意见"),
]

SECTION_REQUIRED = {
    "目的及意义": 1000,
    "基本内容和实施方案": 400,
    "文献综述": 1000,
}

REF_REQUIRED_TOTAL = 8
REF_REQUIRED_RECENT = 4

QUOTE_PATTERNS = [
    re.compile(r"\u201c([^\u201c\u201d]{2,24})\u201d"),
    re.compile(r'"([^"]{2,24})"'),
    re.compile(r"'([^']{2,24})'"),
]


def iter_block_paragraphs(doc):
    """按文档真实顺序遍历正文段落与表格单元格内段落，合并单元格去重。"""
    seen = set()
    for child in doc.element.body.iterchildren():
        if child.tag == qn("w:p"):
            if child not in seen:
                seen.add(child)
                yield Paragraph(child, doc)
        elif child.tag == qn("w:tbl"):
            table = Table(child, doc)
            for row in table.rows:
                for cell in row.cells:
                    for para in cell.paragraphs:
                        node = para._p
                        if node not in seen:
                            seen.add(node)
                            yield para


def collect_items(doc):
    return [
        {
            "index": i,
            "style": (p.style.name if p.style is not None else ""),
            "text": p.text,
        }
        for i, p in enumerate(iter_block_paragraphs(doc))
    ]


def find_boundaries(items):
    """返回 [(index, name), ...]，按出现顺序。"""
    found = []
    for name, marker in SECTION_MARKERS:
        idx = next((it["index"] for it in items if marker in it["text"]), None)
        if idx is not None:
            found.append((idx, name))
    found.sort(key=lambda x: x[0])
    return found


def section_ranges(items, boundaries):
    ranges = {}
    for n, (start, name) in enumerate(boundaries):
        end = boundaries[n + 1][0] if n + 1 < len(boundaries) else len(items)
        ranges[name] = (start, end)
    return ranges


def char_stats(text):
    no_space = re.sub(r"\s", "", text)
    return {
        "char_count_no_space": len(no_space),
        "han_count": len(re.findall(r"[\u4e00-\u9fff]", text)),
    }


def extract_keywords(items, ranges):
    if "文献综述" not in ranges:
        return []
    start, end = ranges["文献综述"]
    hits = []
    for it in items[start:end]:
        if "关键词" not in it["text"]:
            continue
        for pattern in QUOTE_PATTERNS:
            hits.extend(pattern.findall(it["text"]))
    seen = set()
    result = []
    for word in hits:
        word = word.strip()
        if word and word not in seen:
            seen.add(word)
            result.append(word)
    return result


def parse_references(text):
    """解析 [1] 作者. 题名[J]. 刊名,年份,卷期:页码. 形式的条目。"""
    entries = []
    parts = re.split(r"\[(\d{1,2})\]\s*", text)
    if len(parts) >= 3:
        for i in range(1, len(parts) - 1, 2):
            raw = re.sub(r"\s+", " ", parts[i + 1]).strip()
            if raw:
                entries.append({"index": int(parts[i]), "raw": raw})
    if not entries:
        parts = re.split(r"(?:^|\n)\s*(\d{1,2})[\.、]\s*", text)
        for i in range(1, len(parts) - 1, 2):
            raw = re.sub(r"\s+", " ", parts[i + 1]).strip()
            if raw:
                entries.append({"index": int(parts[i]), "raw": raw})

    for entry in entries:
        raw = entry["raw"]
        author = None
        title = None
        kind = None
        m = re.match(r"([^\.。]{2,24})[\.．]\s*(.*)", raw, re.S)
        if m:
            author = m.group(1).strip(" ,，")
            rest = m.group(2)
            km = re.search(r"\[([A-Z])\]", rest)
            if km:
                kind = km.group(1)
                title = rest[: km.start()].strip(" .。")
            else:
                title = rest.split(".")[0].strip(" .。")
        years = re.findall(r"(?:19|20)\d{2}", raw)
        latin = len(re.findall(r"[A-Za-z]", raw))
        entry.update(
            {
                "author": author,
                "title": title,
                "type": kind,
                "year": int(years[0]) if years else None,
                "looks_foreign": bool(raw) and latin / max(len(raw), 1) > 0.35,
            }
        )
    return entries


def check_pinyin_order(entries):
    try:
        from pypinyin import lazy_pinyin
    except ImportError:
        return None, "未安装 pypinyin，排序由模型按作者姓名拼音首字母判断"
    letters = []
    for entry in entries:
        author = entry.get("author") or ""
        if not author:
            continue
        py = lazy_pinyin(author[0])
        if py and py[0]:
            letters.append(py[0][0].upper())
    ok = all(letters[i] <= letters[i + 1] for i in range(len(letters) - 1))
    return ok, "已用 pypinyin 检查作者姓名拼音首字母是否递增"


def build_report(doc_path, base_year):
    doc = Document(doc_path)
    items = collect_items(doc)
    boundaries = find_boundaries(items)
    ranges = section_ranges(items, boundaries)

    sections = {}
    for name, (start, end) in ranges.items():
        if name in SECTION_REQUIRED:
            text = "\n".join(it["text"] for it in items[start:end])
            stats = char_stats(text)
            required = SECTION_REQUIRED[name]
            sections[name] = {
                "paragraph_start": start,
                "paragraph_end": end,
                "required": required,
                "ok": stats["char_count_no_space"] >= required,
                **stats,
            }

    ref_text = ""
    if "参考文献" in ranges:
        start, end = ranges["参考文献"]
        ref_text = "\n".join(it["text"] for it in items[start:end])
    entries = parse_references(ref_text)
    years = [e["year"] for e in entries if e["year"]]
    recent = [y for y in years if base_year - 4 <= y <= base_year]
    order_ok, order_note = check_pinyin_order(entries)

    person_hits = []
    for it in items:
        text = it["text"]
        for m in re.finditer(r"笔者们|我们|我", text):
            s = max(0, m.start() - 18)
            e = min(len(text), m.end() + 18)
            person_hits.append(
                {
                    "paragraph": it["index"],
                    "match": m.group(),
                    "context": text[s:e],
                }
            )

    return {
        "source": os.path.abspath(doc_path),
        "paragraph_count": len(items),
        "paragraphs": items,
        "base_year": base_year,
        "sections": sections,
        "keywords": extract_keywords(items, ranges),
        "references": {
            "count": len(entries),
            "items": entries,
            "recent_5y_count": len(recent),
            "required_total": REF_REQUIRED_TOTAL,
            "required_recent": REF_REQUIRED_RECENT,
            "total_ok": len(entries) >= REF_REQUIRED_TOTAL,
            "recent_ok": len(recent) >= REF_REQUIRED_RECENT,
            "has_foreign": any(e["looks_foreign"] for e in entries),
            "pinyin_order_ok": order_ok,
            "pinyin_order_note": order_note,
        },
        "first_person_hits": person_hits,
        "notes": [
            "字数按非空白字符数（含标点）统计。",
            "第一人称与生造术语仅提供线索，是否记批注由模型按规则判断。",
            "段落索引供 apply 子命令定位，须与本文档保持一致。",
        ],
    }


def find_runs(paragraph, needle):
    """返回覆盖 needle 的 run 序列；找不到返回 None。"""
    runs = [r for r in paragraph.runs if r.text]
    if not runs:
        return None
    full = "".join(r.text for r in runs)
    pos = full.find(needle)
    if pos < 0:
        return None
    end = pos + len(needle)
    offset = 0
    matched = []
    for run in runs:
        start, stop = offset, offset + len(run.text)
        if stop > pos and start < end:
            matched.append(run)
        offset = stop
        if start >= end:
            break
    return matched or None


def cmd_check(args):
    report = build_report(args.input, args.base_year)
    output(args.output, report)


def cmd_refs(args):
    report = build_report(args.input, args.base_year)
    refs = []
    for entry in report["references"]["items"]:
        query = " ".join(x for x in [entry.get("title"), entry.get("author")] if x)
        refs.append(
            {
                "index": entry["index"],
                "author": entry.get("author"),
                "title": entry.get("title"),
                "query": query,
            }
        )
    output(args.output, refs)


def cmd_apply(args):
    doc = Document(args.input)
    if not hasattr(doc, "add_comment"):
        sys.stderr.write(
            "当前 python-docx %s 不支持 Word 原生批注，请升级："
            "pip install --upgrade \"python-docx>=1.2.0\"\n" % getattr(docx, "__version__", "?")
        )
        sys.exit(2)

    with open(args.comments, "r", encoding="utf-8") as fh:
        spec = json.load(fh)
    author = args.author or spec.get("author") or "指导教师"
    initials = args.initials or spec.get("initials") or "导"
    paragraphs = list(iter_block_paragraphs(doc))

    applied, unmatched, failed = 0, [], []
    for n, comment in enumerate(spec.get("comments", [])):
        text = (comment.get("text") or "").strip()
        if not text:
            failed.append({"n": n, "reason": "批注文本为空"})
            continue
        anchor = (comment.get("anchor_text") or "").strip()
        idx = comment.get("paragraph")
        para = None
        if isinstance(idx, int) and 0 <= idx < len(paragraphs):
            para = paragraphs[idx]
        elif anchor:
            para = next((p for p in paragraphs if anchor in p.text), None)
        if para is None:
            failed.append({"n": n, "reason": "段落未定位", "paragraph": idx})
            continue

        runs = find_runs(para, anchor) if anchor else para.runs
        if runs is None:
            unmatched.append(
                {"n": n, "paragraph": idx, "anchor_text": anchor, "fallback": "整段批注"}
            )
            runs = para.runs
        if not runs:
            failed.append({"n": n, "reason": "段落无可锚定的 run", "paragraph": idx})
            continue
        doc.add_comment(runs=runs, text=text, author=author, initials=initials)
        applied += 1

    out = args.output or default_output(args.input)
    doc.save(out)
    result = {
        "output": os.path.abspath(out),
        "applied": applied,
        "unmatched": unmatched,
        "failed": failed,
        "note": "未命中的锚点已降级为整段批注，请人工核对位置。",
    }
    output(None, result)


def default_output(path):
    base, ext = os.path.splitext(path)
    return base + "_批注版" + (ext or ".docx")


def output(path, payload):
    text = json.dumps(payload, ensure_ascii=False, indent=2)
    if path:
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(text + "\n")
        sys.stdout.write("已写入 %s\n" % os.path.abspath(path))
    else:
        sys.stdout.write(text + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="command", required=True)

    p_check = sub.add_parser("check", help="机械核查并输出段落清单 JSON")
    p_check.add_argument("input", help="原稿 .docx 路径")
    p_check.add_argument("-o", "--output", help="报告输出路径，缺省打印到标准输出")
    p_check.add_argument("--base-year", type=int, default=2026, help="近五年基准年，默认 2026")
    p_check.set_defaults(func=cmd_check)

    p_refs = sub.add_parser("refs", help="输出参考文献检索串，供联网核验")
    p_refs.add_argument("input", help="原稿 .docx 路径")
    p_refs.add_argument("-o", "--output", help="输出路径，缺省打印到标准输出")
    p_refs.add_argument("--base-year", type=int, default=2026, help="近五年基准年，默认 2026")
    p_refs.set_defaults(func=cmd_refs)

    p_apply = sub.add_parser("apply", help="写回 Word 原生批注")
    p_apply.add_argument("input", help="原稿 .docx 路径")
    p_apply.add_argument("comments", help="批注清单 .json 路径")
    p_apply.add_argument("-o", "--output", help="输出 .docx 路径")
    p_apply.add_argument("--author", help="批注作者名，默认「指导教师」")
    p_apply.add_argument("--initials", help="批注作者缩写，默认「导」")
    p_apply.set_defaults(func=cmd_apply)

    args = parser.parse_args()
    if not os.path.isfile(args.input):
        sys.stderr.write("找不到输入文件：%s\n" % args.input)
        sys.exit(1)
    args.func(args)


if __name__ == "__main__":
    main()
